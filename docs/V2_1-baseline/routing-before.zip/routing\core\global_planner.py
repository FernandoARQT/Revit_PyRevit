"""Build global constructive options before any movable route is reserved."""
import time
from .topology_graph import TopologyGraph
from .portal_graph import attach
from .connectivity_analysis import analyze
from ..settings import for_route,profile


def solve(space,requests,system_profile,configuration,existing,deadline,cancelled=None,target_route_ids=None,exploration_state=None,candidate_bank=None):
    """Single pure orchestration boundary used by both WPF and MCP."""
    from .multi_route import optimize_multiple_routes
    started=time.monotonic();preparation=None
    if configuration['coordination'].get('topology_enabled',True):
        preparation=prepare(space,requests,configuration,
            min(deadline,started+max(0,deadline-started)*.15),cancelled)
        from .corridor_assignment import assign
        protected=set(configuration['constraints']['locked_routes'])
        if target_route_ids is not None:protected.update(r['route_id'] for r in requests if r['route_id'] not in target_route_ids)
        # Locked/preserved routes retain their source exactly. Their actual
        # reserved geometry remains authoritative in the joint selector.
        movable=[r for r in requests if r['route_id'] not in protected]
        preparation['assignment']=assign(space,movable,configuration,
            min(deadline,time.monotonic()+min(8,max(0,deadline-time.monotonic())*.04)),cancelled)
    result=optimize_multiple_routes(space,requests,system_profile,configuration,existing,cancelled,
        target_route_ids=target_route_ids,absolute_deadline=deadline,exploration_state=exploration_state,candidate_bank=candidate_bank)
    result['global_plan']=preparation
    return result


def prepare(space,requests,configuration,deadline,cancelled=None):
    from .multi_route import compact_anchor,_stub
    from .connector_docking import analyze as docking_analysis
    started=time.monotonic();graphs={};diagnostics={}
    for request in requests:
        rid=request['route_id'];local=for_route(configuration,rid);p=profile(local)
        ports={q['id']:q for q in [request['source']]+request.get('source_alternatives',[]) if q}
        records=[];corridors={}
        for port in ports.values():
            record={'port_id':port['id'],'status':'PENDING_BUDGET'};records.append(record)
            if time.monotonic()>=deadline or (cancelled and cancelled()):continue
            record['docking']=docking_analysis(space,port,p,local)
            anchors=[compact_anchor(space,q,p,local) if request.get('compact_connections') else _stub(q,local['connection_straight_mm'])
                     for q in (port,request['destination'])]
            if not all(anchors) or not all(space.free(a[1],a[1],p.radius_mm) for a in anchors):
                record['status']='BULK_ANCHOR_BLOCKED_FITTING_ALTERNATIVES_PENDING';continue
            start,goal=anchors[0][1],anchors[1][1];key=(p.radius_mm,p.bend_radius_mm)
            if key not in graphs:
                graph=TopologyGraph(space,p.radius_mm,deadline,cancelled)
                attach(graph,start,goal,p,configuration,deadline=deadline,cancelled=cancelled)
                graphs[key]=graph
            result=analyze(graphs[key],start,goal,configuration['coordination'].get('topology_paths',8),deadline,cancelled)
            record.update(status=result['status'],connectivity=result)
            corridors[port['id']]=result['corridors']
            if configuration.get('structural_crossings')=='PROPOSAL_ONLY' and time.monotonic()<deadline:
                bkey=(p.radius_mm,p.bend_radius_mm,'B')
                if bkey not in graphs:
                    graph=TopologyGraph(space,p.radius_mm,deadline,cancelled)
                    attach(graph,start,goal,p,configuration,scenario='B',deadline=deadline,cancelled=cancelled)
                    graphs[bkey]=graph
                conditional=analyze(graphs[bkey],start,goal,configuration['coordination'].get('topology_paths',8),deadline,cancelled)
                record['conditioned_connectivity']=conditional
                corridors[port['id']]=result['corridors']+[dict(c,scenario='B') for c in conditional['corridors']]
        request['port_admission']=records;request['topological_corridors']=corridors
        diagnostics[rid]={'ports':records,'all_ports_accounted':len(records)==len(ports),
            'destination_docking':docking_analysis(space,request['destination'],p,local),
            'corridor_count':sum(len(v) for v in corridors.values())}
    return {'routes':diagnostics,'seconds':time.monotonic()-started,'profile_graphs':len(graphs),
            'scope':'Constructive candidates only; no automatic impossibility or geometric certification'}
